import { db } from '@/lib/db';
import { NextResponse } from 'next/server';
import * as XLSX from 'xlsx';

// دالة تحويل الأرقام للعربية
const toArabicNumbers = (num: number | string | null | undefined): string => {
  if (num === null || num === undefined) return '-';
  const arabicNums = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(num).replace(/[0-9]/g, (d) => arabicNums[parseInt(d)]);
};

// تنسيق التاريخ
const formatDate = (date: Date | string | null): string => {
  if (!date) return '-';
  return new Date(date).toLocaleDateString('ar-SA');
};

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'all';

    const workbook = XLSX.utils.book_new();

    // تسميات الحالات
    const statusLabels: Record<string, string> = {
      'PENDING': 'قيد الانتظار',
      'DIAGNOSING': 'قيد التشخيص',
      'WAITING_PARTS': 'في انتظار القطع',
      'IN_PROGRESS': 'قيد الإصلاح',
      'COMPLETED': 'تم الإصلاح',
      'DELIVERED': 'تم التسليم',
      'CANCELLED': 'ملغي',
      'PAID': 'مدفوعة',
      'PARTIAL': 'مدفوعة جزئياً',
    };

    // تصدير العملاء
    if (type === 'all' || type === 'customers') {
      const customers = await db.customer.findMany({
        orderBy: { createdAt: 'desc' },
      });
      const customersData = customers.map((c, i) => ({
        'الرقم': toArabicNumbers(i + 1),
        'الاسم': c.name,
        'الهاتف': c.phone,
        'البريد الإلكتروني': c.email || '-',
        'العنوان': c.address || '-',
        'ملاحظات': c.notes || '-',
        'تاريخ الإضافة': formatDate(c.createdAt),
      }));
      const customersSheet = XLSX.utils.json_to_sheet(customersData);
      
      // تعيين عرض الأعمدة
      customersSheet['!cols'] = [
        { wch: 8 }, { wch: 20 }, { wch: 15 }, { wch: 25 }, { wch: 20 }, { wch: 25 }, { wch: 15 }
      ];
      
      XLSX.utils.book_append_sheet(workbook, customersSheet, 'العملاء');
    }

    // تصدير طلبات الصيانة
    if (type === 'all' || type === 'repairs') {
      const repairs = await db.repair.findMany({
        include: { customer: true },
        orderBy: { createdAt: 'desc' },
      });
      const repairsData = repairs.map((r, i) => ({
        'الرقم': toArabicNumbers(i + 1),
        'العميل': r.customer?.name || '-',
        'نوع الجهاز': r.deviceType,
        'موديل الجهاز': r.deviceModel,
        'رقم IMEI': r.imei || '-',
        'المشكلة': r.problem,
        'التشخيص': r.diagnosis || '-',
        'الحل': r.solution || '-',
        'الحالة': statusLabels[r.status] || r.status,
        'العربون': toArabicNumbers(r.deposit) + ' د.أ',
        'تكلفة الصيانة': r.maintenanceCost ? toArabicNumbers(r.maintenanceCost) + ' د.أ' : '-',
        'السعر النهائي': r.finalCost ? toArabicNumbers(r.finalCost) + ' د.أ' : '-',
        'المبلغ المدفوع': toArabicNumbers(r.paidAmount) + ' د.أ',
        'الدين': toArabicNumbers(r.debt) + ' د.أ',
        'تاريخ الاستلام': formatDate(r.receivedAt),
        'تاريخ التسليم': formatDate(r.deliveredAt),
      }));
      const repairsSheet = XLSX.utils.json_to_sheet(repairsData);
      repairsSheet['!cols'] = [
        { wch: 8 }, { wch: 15 }, { wch: 12 }, { wch: 15 }, { wch: 18 },
        { wch: 25 }, { wch: 20 }, { wch: 20 }, { wch: 12 },
        { wch: 12 }, { wch: 15 }, { wch: 12 }, { wch: 12 }, { wch: 12 },
        { wch: 15 }, { wch: 15 }
      ];
      XLSX.utils.book_append_sheet(workbook, repairsSheet, 'طلبات الصيانة');
    }

    // تصدير المخزون
    if (type === 'all' || type === 'inventory') {
      const inventory = await db.inventory.findMany({
        orderBy: { createdAt: 'desc' },
      });
      const inventoryData = inventory.map((item, i) => ({
        'الرقم': toArabicNumbers(i + 1),
        'اسم القطعة': item.name,
        'الفئة': item.category,
        'الماركة': item.brand || '-',
        'الكمية': toArabicNumbers(item.quantity),
        'الحد الأدنى': toArabicNumbers(item.minQuantity),
        'سعر الشراء': toArabicNumbers(item.costPrice) + ' د.أ',
        'سعر البيع': toArabicNumbers(item.sellingPrice) + ' د.أ',
        'الموقع': item.location || '-',
        'ملاحظات': item.notes || '-',
      }));
      const inventorySheet = XLSX.utils.json_to_sheet(inventoryData);
      inventorySheet['!cols'] = [
        { wch: 8 }, { wch: 25 }, { wch: 15 }, { wch: 15 },
        { wch: 10 }, { wch: 12 }, { wch: 15 }, { wch: 15 },
        { wch: 15 }, { wch: 20 }
      ];
      XLSX.utils.book_append_sheet(workbook, inventorySheet, 'المخزون');
    }

    // تصدير الفواتير
    if (type === 'all' || type === 'invoices') {
      const invoices = await db.invoice.findMany({
        include: { customer: true },
        orderBy: { createdAt: 'desc' },
      });
      const invoicesData = invoices.map((inv, i) => ({
        'الرقم': toArabicNumbers(i + 1),
        'رقم الفاتورة': inv.invoiceNumber,
        'العميل': inv.customer?.name || '-',
        'المجموع الفرعي': toArabicNumbers(inv.subtotal) + ' د.أ',
        'الخصم': toArabicNumbers(inv.discount) + ' د.أ',
        'الضريبة': toArabicNumbers(inv.tax) + ' د.أ',
        'الإجمالي': toArabicNumbers(inv.total) + ' د.أ',
        'المدفوع': toArabicNumbers(inv.paid) + ' د.أ',
        'الحالة': statusLabels[inv.status] || inv.status,
        'تاريخ الإنشاء': formatDate(inv.createdAt),
      }));
      const invoicesSheet = XLSX.utils.json_to_sheet(invoicesData);
      invoicesSheet['!cols'] = [
        { wch: 8 }, { wch: 15 }, { wch: 15 }, { wch: 15 },
        { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 },
        { wch: 15 }, { wch: 15 }
      ];
      XLSX.utils.book_append_sheet(workbook, invoicesSheet, 'الفواتير');
    }

    // تصدير المصاريف
    if (type === 'all' || type === 'expenses') {
      const expenses = await db.expense.findMany({
        orderBy: { date: 'desc' },
      });
      const expensesData = expenses.map((e, i) => ({
        'الرقم': toArabicNumbers(i + 1),
        'الفئة': e.category,
        'الوصف': e.description,
        'المبلغ': toArabicNumbers(e.amount) + ' د.أ',
        'التاريخ': formatDate(e.date),
        'ملاحظات': e.notes || '-',
      }));
      const expensesSheet = XLSX.utils.json_to_sheet(expensesData);
      expensesSheet['!cols'] = [
        { wch: 8 }, { wch: 15 }, { wch: 30 },
        { wch: 12 }, { wch: 15 }, { wch: 20 }
      ];
      XLSX.utils.book_append_sheet(workbook, expensesSheet, 'المصاريف');
    }

    // إنشاء الملف
    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    // تحديد اسم الملف
    const date = new Date().toISOString().split('T')[0];
    const fileName = type === 'all' 
      ? `تصدير_البيانات_${date}.xlsx` 
      : `تصدير_${type}_${date}.xlsx`;

    return new NextResponse(buffer, {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="${encodeURIComponent(fileName)}"`,
      },
    });
  } catch (error) {
    console.error('Error exporting data:', error);
    return NextResponse.json({ error: 'Error exporting data' }, { status: 500 });
  }
}
