'use client';

import { useState, useEffect, useSyncExternalStore } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Wrench, 
  Users, 
  Package,
  BarChart3,
  PieChart,
  Calculator,
  Loader2
} from 'lucide-react';
import { useAppStore } from '@/store';
import { ExportDialog } from '@/components/export/ExportButton';
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, PieChart as RechartsPieChart, Pie, Cell, ResponsiveContainer, LabelList } from 'recharts';

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

// Helper for client-side only rendering
const emptySubscribe = () => () => {};
const getClientSnapshot = () => true;
const getServerSnapshot = () => false;

export function ReportsPage() {
  const { customers, repairs, invoices, expenses, inventory } = useAppStore();
  const [period, setPeriod] = useState<'week' | 'month' | 'year'>('month');
  const mounted = useSyncExternalStore(emptySubscribe, getClientSnapshot, getServerSnapshot);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [customersRes, repairsRes, invoicesRes, expensesRes, inventoryRes] = await Promise.all([
          fetch('/api/customers'),
          fetch('/api/repairs'),
          fetch('/api/invoices'),
          fetch('/api/expenses'),
          fetch('/api/inventory'),
        ]);
        if (customersRes.ok) useAppStore.getState().setCustomers(await customersRes.json());
        if (repairsRes.ok) useAppStore.getState().setRepairs(await repairsRes.json());
        if (invoicesRes.ok) useAppStore.getState().setInvoices(await invoicesRes.json());
        if (expensesRes.ok) useAppStore.getState().setExpenses(await expensesRes.json());
        if (inventoryRes.ok) useAppStore.getState().setInventory(await inventoryRes.json());
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  // حساب تاريخ البداية حسب الفترة
  const getStartDate = () => {
    const now = new Date();
    switch (period) {
      case 'week':
        return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      case 'month':
        return new Date(now.getFullYear(), now.getMonth(), 1);
      case 'year':
        return new Date(now.getFullYear(), 0, 1);
    }
  };

  const startDate = getStartDate();

  // تصفية البيانات حسب الفترة
  const filteredInvoices = invoices.filter(i => new Date(i.createdAt) >= startDate);
  const filteredExpenses = expenses.filter(e => new Date(e.date) >= startDate);
  const filteredRepairs = repairs.filter(r => new Date(r.createdAt) >= startDate);
  
  // فقط التسليمات (DELIVERED) تُحتسب في الأرباح
  const deliveredRepairs = repairs.filter(r => r.status === 'DELIVERED');
  const filteredDeliveredRepairs = deliveredRepairs.filter(r => new Date(r.createdAt) >= startDate);

  // === حساب الإحصائيات الجديدة ===
  
  // إجمالي الإيرادات (الفواتير المدفوعة)
  const totalRevenue = filteredInvoices.reduce((sum, i) => sum + i.paid, 0);
  
  // إجمالي المصاريف التشغيلية
  const totalExpenses = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
  
  // إجمالي تكاليف الصيانة (قطع الغيار + مواد) - من التسليمات فقط
  const totalMaintenanceCosts = filteredDeliveredRepairs
    .filter(r => r.maintenanceCost)
    .reduce((sum, r) => sum + (r.maintenanceCost || 0), 0);
  
  // إجمالي أرباح الصيانة (السعر النهائي - تكلفة الصيانة) - من التسليمات فقط
  const totalRepairsProfit = filteredDeliveredRepairs
    .filter(r => r.finalCost && r.maintenanceCost)
    .reduce((sum, r) => sum + ((r.finalCost || 0) - (r.maintenanceCost || 0)), 0);
  
  // الديون المستحقة من التسليمات
  const totalDebts = filteredDeliveredRepairs
    .reduce((sum, r) => sum + (r.debt || 0), 0);
  
  // صافي الربح الكلي = أرباح الصيانة + الفواتير - المصاريف
  const netProfit = totalRepairsProfit + totalRevenue - totalExpenses;
  
  // إحصائيات الصيانة
  const completedRepairs = filteredRepairs.filter(r => r.status === 'COMPLETED' || r.status === 'DELIVERED').length;
  const pendingRepairs = filteredRepairs.filter(r => 
    r.status === 'PENDING' || r.status === 'IN_PROGRESS' || r.status === 'DIAGNOSING'
  ).length;

  // بيانات الرسم البياني
  const monthlyData = (() => {
    const months = period === 'year' 
      ? Array.from({ length: 12 }, (_, i) => i)
      : period === 'month'
      ? Array.from({ length: 4 }, (_, i) => i)
      : Array.from({ length: 7 }, (_, i) => i);

    return months.map((_, index) => {
      const now = new Date();
      let startDate: Date;
      let endDate: Date;
      let label: string;

      if (period === 'year') {
        startDate = new Date(now.getFullYear(), index, 1);
        endDate = new Date(now.getFullYear(), index + 1, 0);
        label = new Date(now.getFullYear(), index, 1).toLocaleDateString('ar-SA', { month: 'short' });
      } else if (period === 'month') {
        startDate = new Date(now.getFullYear(), now.getMonth(), index * 7 + 1);
        endDate = new Date(now.getFullYear(), now.getMonth(), Math.min((index + 1) * 7, 30));
        label = `الأسبوع ${index + 1}`;
      } else {
        startDate = new Date(now.getTime() - (6 - index) * 24 * 60 * 60 * 1000);
        endDate = startDate;
        label = startDate.toLocaleDateString('ar-SA', { weekday: 'short' });
      }

      // أرباح الصيانة في الفترة (من التسليمات فقط)
      const periodRepairsProfit = deliveredRepairs
        .filter(r => {
          const date = new Date(r.createdAt);
          return date >= startDate && date <= endDate && r.finalCost && r.maintenanceCost;
        })
        .reduce((sum, r) => sum + ((r.finalCost || 0) - (r.maintenanceCost || 0)), 0);

      const periodRevenue = invoices
        .filter(i => {
          const date = new Date(i.createdAt);
          return date >= startDate && date <= endDate;
        })
        .reduce((sum, i) => sum + i.paid, 0);

      const periodExpenses = expenses
        .filter(e => {
          const date = new Date(e.date);
          return date >= startDate && date <= endDate;
        })
        .reduce((sum, e) => sum + e.amount, 0);

      return {
        name: label,
        repairsProfit: periodRepairsProfit,
        revenue: periodRevenue,
        expenses: periodExpenses,
        profit: periodRepairsProfit + periodRevenue - periodExpenses,
      };
    });
  })();

  // بيانات أنواع الأجهزة
  const deviceTypeData = (() => {
    const deviceCounts: Record<string, number> = {};
    repairs.forEach(r => {
      deviceCounts[r.deviceType] = (deviceCounts[r.deviceType] || 0) + 1;
    });
    return Object.entries(deviceCounts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);
  })();

  // بيانات حالات الصيانة
  const repairStatusData = [
    { name: 'قيد الانتظار', value: repairs.filter(r => r.status === 'PENDING').length, color: '#f59e0b' },
    { name: 'قيد الإصلاح', value: repairs.filter(r => r.status === 'IN_PROGRESS' || r.status === 'DIAGNOSING').length, color: '#3b82f6' },
    { name: 'مكتمل', value: repairs.filter(r => r.status === 'COMPLETED' || r.status === 'DELIVERED').length, color: '#10b981' },
    { name: 'ملغي', value: repairs.filter(r => r.status === 'CANCELLED').length, color: '#ef4444' },
  ].filter(d => d.value > 0);

  // بيانات فئات المصاريف
  const expenseCategoryData = (() => {
    const categoryTotals: Record<string, number> = {};
    filteredExpenses.forEach(e => {
      categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
    });
    return Object.entries(categoryTotals)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  })();

  // أعلى العملاء
  const topCustomers = (() => {
    const customerTotals: Record<string, { name: string; total: number; repairs: number }> = {};
    invoices.forEach(i => {
      if (i.customerId) {
        const customer = customers.find(c => c.id === i.customerId);
        if (customer) {
          if (!customerTotals[i.customerId]) {
            customerTotals[i.customerId] = { name: customer.name, total: 0, repairs: 0 };
          }
          customerTotals[i.customerId].total += i.total;
        }
      }
    });
    repairs.forEach(r => {
      if (customerTotals[r.customerId]) {
        customerTotals[r.customerId].repairs++;
      }
    });
    return Object.entries(customerTotals)
      .map(([id, data]) => ({ id, ...data }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  })();

  // أعلى الصيانات ربحية - من التسليمات فقط
  const topProfitableRepairs = filteredDeliveredRepairs
    .filter(r => r.finalCost && r.maintenanceCost)
    .map(r => ({
      id: r.id,
      device: `${r.deviceType} - ${r.deviceModel}`,
      customer: customers.find(c => c.id === r.customerId)?.name || 'غير معروف',
      maintenanceCost: r.maintenanceCost || 0,
      finalCost: r.finalCost || 0,
      profit: (r.finalCost || 0) - (r.maintenanceCost || 0),
    }))
    .sort((a, b) => b.profit - a.profit)
    .slice(0, 5);

  // Custom legend renderer for pie charts
  const renderCustomLegend = (data: { name: string; value: number; color?: string }[], colors?: string[]) => (
    <div className="flex flex-wrap justify-center gap-4 mt-4">
      {data.map((entry, index) => (
        <div key={entry.name} className="flex items-center gap-2">
          <div 
            className="w-3 h-3 rounded-full" 
            style={{ backgroundColor: entry.color || colors?.[index % (colors?.length || 1)] }}
          />
          <span className="text-sm">{entry.name}: {entry.value}</span>
        </div>
      ))}
    </div>
  );

  if (!mounted) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* العنوان */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">التقارير المالية</h1>
          <p className="text-muted-foreground">تحليل الأداء المالي والتشغيلي</p>
        </div>
        <div className="flex items-center gap-2">
          <ExportDialog />
          <Select value={period} onValueChange={(v) => setPeriod(v as 'week' | 'month' | 'year')}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">هذا الأسبوع</SelectItem>
              <SelectItem value="month">هذا الشهر</SelectItem>
              <SelectItem value="year">هذا العام</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* بطاقات الإحصائيات */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">أرباح الصيانة</p>
                <p className="text-2xl font-bold text-green-600">{totalRepairsProfit.toLocaleString()} د.أ</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-orange-100 dark:bg-orange-900/20 rounded-lg">
                <Calculator className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">تكاليف الصيانة</p>
                <p className="text-2xl font-bold text-orange-600">{totalMaintenanceCosts.toLocaleString()} د.أ</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-red-100 dark:bg-red-900/20 rounded-lg">
                <TrendingDown className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">المصاريف التشغيلية</p>
                <p className="text-2xl font-bold text-red-600">{totalExpenses.toLocaleString()} د.أ</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className={`p-3 rounded-lg ${netProfit >= 0 ? 'bg-blue-100 dark:bg-blue-900/20' : 'bg-red-100 dark:bg-red-900/20'}`}>
                <DollarSign className={`h-6 w-6 ${netProfit >= 0 ? 'text-blue-600' : 'text-red-600'}`} />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">صافي الربح</p>
                <p className={`text-2xl font-bold ${netProfit >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                  {netProfit.toLocaleString()} د.أ
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* بطاقة توضيحية لحساب الأرباح */}
      <Card className="bg-gradient-to-r from-blue-50 to-green-50 dark:from-blue-950/20 dark:to-green-950/20 border-blue-200 dark:border-blue-800">
        <CardContent className="pt-6">
          <div className="space-y-3">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              طريقة حساب الأرباح
            </h3>
            <p className="text-sm text-muted-foreground">
              ⚠️ يتم احتساب الأرباح فقط من الطلبات المسلمة (تم التسليم)
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                <p className="font-medium text-green-600">أرباح الصيانة</p>
                <p className="text-muted-foreground">السعر النهائي - تكلفة الصيانة</p>
                <p className="font-bold mt-1">{totalRepairsProfit.toLocaleString()} د.أ</p>
              </div>
              <div className="p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                <p className="font-medium text-blue-600">+ الإيرادات الأخرى</p>
                <p className="text-muted-foreground">مبيعات، فواتير إضافية</p>
                <p className="font-bold mt-1">{totalRevenue.toLocaleString()} د.أ</p>
              </div>
              <div className="p-3 bg-white/50 dark:bg-black/20 rounded-lg">
                <p className="font-medium text-red-600">- المصاريف التشغيلية</p>
                <p className="text-muted-foreground">إيجار، كهرباء، رواتب...</p>
                <p className="font-bold mt-1">{totalExpenses.toLocaleString()} د.أ</p>
              </div>
            </div>
            <div className="text-center p-3 bg-white/70 dark:bg-black/30 rounded-lg">
              <span className="text-muted-foreground">صافي الربح = </span>
              <span className="text-green-600 font-bold">{totalRepairsProfit.toLocaleString()}</span>
              <span className="text-muted-foreground"> + </span>
              <span className="text-blue-600 font-bold">{totalRevenue.toLocaleString()}</span>
              <span className="text-muted-foreground"> - </span>
              <span className="text-red-600 font-bold">{totalExpenses.toLocaleString()}</span>
              <span className="text-muted-foreground"> = </span>
              <span className={`font-bold text-xl ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {netProfit.toLocaleString()} د.أ
              </span>
            </div>
            {totalDebts > 0 && (
              <div className="p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800">
                <p className="text-orange-600 font-medium">
                  💰 ديون العملاء المستحقة: {totalDebts.toLocaleString()} د.أ
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* الرسوم البيانية */}
      <div className="grid grid-cols-1 gap-6">
        {/* رسم بياني للأرباح والمصاريف */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              الأرباح والمصاريف
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="w-full h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData} margin={{ top: 20, right: 5, left: 5, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fill: 'hsl(var(--foreground))', fontSize: 11 }}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                  />
                  <YAxis 
                    width={40}
                    tick={{ fill: 'hsl(var(--foreground))', fontSize: 11 }}
                    axisLine={{ stroke: 'hsl(var(--border))' }}
                  />
                  <Bar dataKey="repairsProfit" fill="#10b981" name="أرباح الصيانة" radius={[4, 4, 0, 0]}>
                    <LabelList 
                      dataKey="repairsProfit" 
                      position="top" 
                      formatter={(value: number) => value > 0 ? value.toLocaleString() : ''}
                      style={{ fill: '#10b981', fontSize: 10, fontWeight: 'bold' }}
                    />
                  </Bar>
                  <Bar dataKey="expenses" fill="#ef4444" name="المصاريف" radius={[4, 4, 0, 0]}>
                    <LabelList 
                      dataKey="expenses" 
                      position="top" 
                      formatter={(value: number) => value > 0 ? value.toLocaleString() : ''}
                      style={{ fill: '#ef4444', fontSize: 10, fontWeight: 'bold' }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            {/* Legend */}
            <div className="flex justify-center gap-6 mt-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-sm">أرباح الصيانة</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-sm">المصاريف</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* الرسوم الدائرية */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* رسم دائري لحالات الصيانة */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              حالات الصيانة
            </CardTitle>
          </CardHeader>
          <CardContent>
            {repairStatusData.length > 0 ? (
              <div className="h-[280px] w-full flex flex-col items-center">
                <ResponsiveContainer width="100%" height={220}>
                  <RechartsPieChart>
                    <Pie
                      data={repairStatusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={85}
                      dataKey="value"
                    >
                      {repairStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </RechartsPieChart>
                </ResponsiveContainer>
                {renderCustomLegend(repairStatusData)}
              </div>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                لا توجد بيانات لعرضها
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* أعلى الصيانات ربحية */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            أعلى الصيانات ربحية
          </CardTitle>
        </CardHeader>
        <CardContent>
          {topProfitableRepairs.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>#</TableHead>
                    <TableHead>الجهاز</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>تكلفة الصيانة</TableHead>
                    <TableHead>السعر النهائي</TableHead>
                    <TableHead>الربح</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topProfitableRepairs.map((repair, index) => (
                    <TableRow key={repair.id}>
                      <TableCell className="font-bold">{index + 1}</TableCell>
                      <TableCell>{repair.device}</TableCell>
                      <TableCell>{repair.customer}</TableCell>
                      <TableCell className="text-orange-600">{repair.maintenanceCost.toLocaleString()} د.أ</TableCell>
                      <TableCell className="text-blue-600">{repair.finalCost.toLocaleString()} د.أ</TableCell>
                      <TableCell className="text-green-600 font-bold">{repair.profit.toLocaleString()} د.أ</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              لا توجد بيانات كافية (يتم احتساب الأرباح من الطلبات المسلمة فقط)
            </div>
          )}
        </CardContent>
      </Card>

      {/* المزيد من الرسوم البيانية */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* أنواع الأجهزة */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              أنواع الأجهزة الأكثر صيانة
            </CardTitle>
          </CardHeader>
          <CardContent>
            {deviceTypeData.length > 0 ? (
              <div className="h-[280px] w-full flex flex-col items-center">
                <ResponsiveContainer width="100%" height={220}>
                  <RechartsPieChart>
                    <Pie
                      data={deviceTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={85}
                      dataKey="value"
                    >
                      {deviceTypeData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                  </RechartsPieChart>
                </ResponsiveContainer>
                {renderCustomLegend(deviceTypeData, COLORS)}
              </div>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                لا توجد بيانات لعرضها
              </div>
            )}
          </CardContent>
        </Card>

        {/* فئات المصاريف */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5" />
              توزيع المصاريف حسب الفئة
            </CardTitle>
          </CardHeader>
          <CardContent>
            {expenseCategoryData.length > 0 ? (
              <div className="space-y-4">
                {expenseCategoryData.slice(0, 6).map((item, index) => {
                  const total = expenseCategoryData.reduce((sum, i) => sum + i.value, 0);
                  const percentage = ((item.value / total) * 100).toFixed(1);
                  return (
                    <div key={item.name} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{item.name}</span>
                        <span>{item.value.toLocaleString()} د.أ ({percentage}%)</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div
                          className="h-2 rounded-full transition-all"
                          style={{
                            width: `${percentage}%`,
                            backgroundColor: COLORS[index % COLORS.length],
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                لا توجد مصاريف مسجلة
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* أعلى العملاء */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            أعلى العملاء
          </CardTitle>
        </CardHeader>
        <CardContent>
          {topCustomers.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>#</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>عدد الطلبات</TableHead>
                    <TableHead>إجمالي المشتريات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topCustomers.map((customer, index) => (
                    <TableRow key={customer.id}>
                      <TableCell className="font-bold">{index + 1}</TableCell>
                      <TableCell>{customer.name}</TableCell>
                      <TableCell>{customer.repairs}</TableCell>
                      <TableCell className="font-medium">{customer.total.toLocaleString()} د.أ</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              لا توجد بيانات عملاء
            </div>
          )}
        </CardContent>
      </Card>

      {/* ملخص المخزون */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            ملخص المخزون
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-secondary rounded-lg text-center">
              <p className="text-muted-foreground">إجمالي المنتجات</p>
              <p className="text-2xl font-bold">{inventory.length}</p>
            </div>
            <div className="p-4 bg-secondary rounded-lg text-center">
              <p className="text-muted-foreground">إجمالي القطع</p>
              <p className="text-2xl font-bold">
                {inventory.reduce((sum, i) => sum + i.quantity, 0)}
              </p>
            </div>
            <div className="p-4 bg-secondary rounded-lg text-center">
              <p className="text-muted-foreground">قيمة المخزون</p>
              <p className="text-2xl font-bold">
                {inventory.reduce((sum, i) => sum + (i.costPrice * i.quantity), 0).toLocaleString()} د.أ
              </p>
            </div>
          </div>
          {inventory.filter(i => i.quantity <= i.minQuantity).length > 0 && (
            <div className="mt-4 p-4 bg-red-50 dark:bg-red-950/20 rounded-lg">
              <p className="text-red-600 font-medium">
                ⚠️ يوجد {inventory.filter(i => i.quantity <= i.minQuantity).length} منتج بكمية منخفضة
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
