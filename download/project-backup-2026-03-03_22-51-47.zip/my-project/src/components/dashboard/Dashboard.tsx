'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Users, 
  Wrench, 
  Package, 
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertTriangle,
  Calculator,
  ChevronLeft,
  CreditCard
} from 'lucide-react';
import { useAppStore } from '@/store';

interface DashboardProps {
  onNavigate: (page: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { customers, repairs, inventory, invoices, expenses } = useAppStore();

  // === حساب الإحصائيات ===
  // فقط حساب الأرباح من الطلبات المسلمة (DELIVERED)
  const deliveredRepairs = repairs.filter(r => r.status === 'DELIVERED');
  
  const totalRepairsProfit = deliveredRepairs
    .filter(r => r.finalCost && r.maintenanceCost)
    .reduce((sum, r) => sum + ((r.finalCost || 0) - (r.maintenanceCost || 0)), 0);
  
  const totalMaintenanceCosts = deliveredRepairs
    .filter(r => r.maintenanceCost)
    .reduce((sum, r) => sum + (r.maintenanceCost || 0), 0);
  
  const totalFinalCosts = deliveredRepairs
    .filter(r => r.finalCost)
    .reduce((sum, r) => sum + (r.finalCost || 0), 0);
  
  // الديون المستحقة من التسليمات
  const totalDebts = deliveredRepairs
    .reduce((sum, r) => sum + (r.debt || 0), 0);
  
  // المبالغ المدفوعة من التسليمات
  const totalPaidAmounts = deliveredRepairs
    .reduce((sum, r) => sum + (r.paidAmount || 0), 0);

  const totalRevenue = invoices
    .filter(i => i.status === 'PAID')
    .reduce((sum, i) => sum + i.paid, 0);

  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);

  const netProfit = totalRepairsProfit + totalRevenue - totalExpenses;

  const pendingRepairs = repairs.filter(r => 
    r.status === 'PENDING' || r.status === 'DIAGNOSING' || r.status === 'IN_PROGRESS'
  ).length;

  const completedRepairs = repairs.filter(r => r.status === 'COMPLETED' || r.status === 'DELIVERED').length;

  const lowStockItems = inventory.filter(i => i.quantity <= i.minQuantity).length;

  const pendingPayments = invoices
    .filter(i => i.status === 'PENDING' || i.status === 'PARTIAL')
    .reduce((sum, i) => sum + (i.total - i.paid), 0);

  // حالة الصيانة
  const statusColors: Record<string, string> = {
    PENDING: 'bg-yellow-500',
    DIAGNOSING: 'bg-blue-500',
    WAITING_PARTS: 'bg-orange-500',
    IN_PROGRESS: 'bg-purple-500',
    COMPLETED: 'bg-green-500',
    DELIVERED: 'bg-teal-500',
    CANCELLED: 'bg-red-500',
  };

  const statusLabels: Record<string, string> = {
    PENDING: 'قيد الانتظار',
    DIAGNOSING: 'قيد التشخيص',
    WAITING_PARTS: 'في انتظار القطع',
    IN_PROGRESS: 'قيد الإصلاح',
    COMPLETED: 'تم الإصلاح',
    DELIVERED: 'تم التسليم',
    CANCELLED: 'ملغي',
  };

  const statusCounts = repairs.reduce((acc, repair) => {
    acc[repair.status] = (acc[repair.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const recentRepairs = [...repairs]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const topProfitableRepairs = [...deliveredRepairs]
    .filter(r => r.finalCost && r.maintenanceCost)
    .map(r => ({
      ...r,
      profit: (r.finalCost || 0) - (r.maintenanceCost || 0)
    }))
    .sort((a, b) => b.profit - a.profit)
    .slice(0, 3);

  // بطاقات الإحصائيات السريعة
  const quickStats = [
    { label: 'أرباح الصيانة', value: totalRepairsProfit, icon: TrendingUp, color: 'text-emerald-600 dark:text-emerald-400', iconBg: 'bg-emerald-500' },
    { label: 'صافي الربح', value: netProfit, icon: DollarSign, color: netProfit >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-rose-600 dark:text-rose-400', iconBg: netProfit >= 0 ? 'bg-blue-500' : 'bg-rose-500' },
    { label: 'ديون العملاء', value: totalDebts, icon: AlertTriangle, color: totalDebts > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-green-600 dark:text-green-400', iconBg: totalDebts > 0 ? 'bg-rose-500' : 'bg-green-500' },
    { label: 'المصاريف', value: totalExpenses, icon: Calculator, color: 'text-amber-600 dark:text-amber-400', iconBg: 'bg-amber-500' },
  ];

  // القوائم السريعة
  const quickActions = [
    { label: 'العملاء', count: customers.length, icon: Users, page: 'customers', color: 'bg-primary' },
    { label: 'الصيانة', count: repairs.length, icon: Wrench, page: 'repairs', color: 'bg-blue-500' },
    { label: 'المخزون', count: inventory.length, icon: Package, page: 'inventory', color: 'bg-orange-500' },
    { label: 'الفواتير', count: invoices.length, icon: DollarSign, page: 'invoices', color: 'bg-green-500' },
  ];

  return (
    <div className="space-y-4 md:space-y-6 max-w-7xl mx-auto">
      {/* العنوان */}
      <div>
        <h1 className="text-2xl md:text-3xl font-bold">لوحة التحكم</h1>
        <p className="text-sm md:text-base text-muted-foreground">مرحباً بك في نظام محاسبة صيانة الموبايل</p>
      </div>

      {/* بطاقات الأرباح - قابلة للتمرير على الهاتف */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 md:gap-4">
        {quickStats.map((stat, index) => (
          <Card key={index} className="border">
            <CardContent className="p-3 md:p-4">
              <div className="flex items-center gap-2 md:gap-3">
                <div className={`p-1.5 md:p-2 rounded-lg ${stat.iconBg}`}>
                  <stat.icon className="h-4 w-4 md:h-5 md:w-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs md:text-sm text-muted-foreground truncate">{stat.label}</p>
                  <p className={`text-base md:text-xl font-bold ${stat.color}`}>
                    {stat.value.toLocaleString()} د.أ
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* القوائم السريعة */}
      <div className="grid grid-cols-4 gap-2">
        {quickActions.map((action) => (
          <Button
            key={action.page}
            variant="outline"
            className="h-auto flex-col gap-1 md:gap-2 py-3 md:py-4"
            onClick={() => onNavigate(action.page)}
          >
            <div className={`p-2 rounded-lg ${action.color}`}>
              <action.icon className="h-4 w-4 md:h-5 md:w-5 text-white" />
            </div>
            <span className="text-xs md:text-sm font-medium">{action.label}</span>
            <span className="text-xs md:text-sm font-bold">{action.count}</span>
          </Button>
        ))}
      </div>

      {/* إحصائيات إضافية */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
        <Card>
          <CardContent className="p-3 md:p-4 text-center">
            <CheckCircle className="h-6 w-6 md:h-8 md:w-8 mx-auto text-green-500 mb-2" />
            <p className="text-xl md:text-2xl font-bold">{completedRepairs}</p>
            <p className="text-xs md:text-sm text-muted-foreground">مكتملة</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 md:p-4 text-center">
            <Clock className="h-6 w-6 md:h-8 md:w-8 mx-auto text-yellow-500 mb-2" />
            <p className="text-xl md:text-2xl font-bold">{pendingRepairs}</p>
            <p className="text-xs md:text-sm text-muted-foreground">قيد المعالجة</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 md:p-4 text-center">
            <TrendingUp className="h-6 w-6 md:h-8 md:w-8 mx-auto text-purple-500 mb-2" />
            <p className="text-xl md:text-2xl font-bold">{pendingPayments.toLocaleString()}</p>
            <p className="text-xs md:text-sm text-muted-foreground">مستحقات (د.أ)</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 md:p-4 text-center">
            <DollarSign className="h-6 w-6 md:h-8 md:w-8 mx-auto text-teal-500 mb-2" />
            <p className="text-xl md:text-2xl font-bold">{totalFinalCosts.toLocaleString()}</p>
            <p className="text-xs md:text-sm text-muted-foreground">مبيعات (د.أ)</p>
          </CardContent>
        </Card>
      </div>

      {/* حالة الصيانة وآخر الطلبات */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* حالة الصيانة */}
        <Card>
          <CardHeader className="pb-2 md:pb-4">
            <CardTitle className="text-base md:text-lg">حالة طلبات الصيانة</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 md:space-y-3">
            {Object.entries(statusCounts).length > 0 ? (
              Object.entries(statusCounts).map(([status, count]) => (
                <div key={status} className="flex items-center gap-2 md:gap-3">
                  <div className={`w-2.5 h-2.5 md:w-3 md:h-3 rounded-full ${statusColors[status]}`} />
                  <span className="flex-1 text-sm md:text-base">{statusLabels[status]}</span>
                  <span className="font-bold text-sm md:text-base">{count}</span>
                  <div className="w-16 md:w-24 bg-secondary rounded-full h-1.5 md:h-2">
                    <div 
                      className={`h-1.5 md:h-2 rounded-full ${statusColors[status]}`}
                      style={{ width: `${(count / repairs.length) * 100}%` }}
                    />
                  </div>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-4 text-sm">لا توجد طلبات صيانة</p>
            )}
          </CardContent>
        </Card>

        {/* أعلى الصيانات ربحية */}
        <Card>
          <CardHeader className="pb-2 md:pb-4 flex flex-row items-center justify-between">
            <CardTitle className="text-base md:text-lg">أعلى الصيانات ربحية</CardTitle>
            <Button variant="ghost" size="sm" className="text-xs" onClick={() => onNavigate('reports')}>
              المزيد
              <ChevronLeft className="h-4 w-4 mr-1" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-2 md:space-y-3">
            {topProfitableRepairs.length > 0 ? (
              topProfitableRepairs.map((repair) => (
                <div key={repair.id} className="flex items-center gap-2 md:gap-3 p-2 md:p-3 bg-secondary/50 rounded-lg">
                  <div className="p-1.5 md:p-2 bg-green-500 rounded-lg">
                    <TrendingUp className="h-3 w-3 md:h-4 md:w-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm md:text-base truncate">{repair.deviceModel}</p>
                    <p className="text-xs text-muted-foreground truncate">{repair.problem}</p>
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-green-600 text-sm md:text-base">{repair.profit.toLocaleString()} د.أ</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground text-sm">لا توجد بيانات أرباح</p>
                <p className="text-xs text-muted-foreground mt-1">أضف تكلفة الصيانة والسعر النهائي</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* آخر الطلبات */}
      <Card>
        <CardHeader className="pb-2 md:pb-4 flex flex-row items-center justify-between">
          <CardTitle className="text-base md:text-lg">آخر طلبات الصيانة</CardTitle>
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => onNavigate('repairs')}>
            عرض الكل
            <ChevronLeft className="h-4 w-4 mr-1" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 md:gap-3">
            {recentRepairs.length > 0 ? (
              recentRepairs.map((repair) => {
                const profit = repair.status === 'DELIVERED' && repair.finalCost && repair.maintenanceCost 
                  ? repair.finalCost - repair.maintenanceCost 
                  : null;
                const potentialProfit = repair.status !== 'DELIVERED' && repair.finalCost && repair.maintenanceCost 
                  ? repair.finalCost - repair.maintenanceCost 
                  : null;
                return (
                  <div key={repair.id} className="p-3 md:p-4 border rounded-lg hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-2 gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm md:text-base truncate">{repair.deviceType} - {repair.deviceModel}</p>
                        <p className="text-xs md:text-sm text-muted-foreground truncate">{repair.problem}</p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full text-white whitespace-nowrap ${statusColors[repair.status]}`}>
                        {statusLabels[repair.status]}
                      </span>
                    </div>
                    {profit !== null && (
                      <div className="flex items-center gap-2 mt-2 pt-2 border-t">
                        <TrendingUp className="h-3.5 w-3.5 text-green-500" />
                        <span className="text-xs text-muted-foreground">الربح:</span>
                        <span className="font-bold text-green-600 text-sm">{profit.toLocaleString()} د.أ</span>
                      </div>
                    )}
                    {potentialProfit !== null && (
                      <div className="flex items-center gap-2 mt-2 pt-2 border-t">
                        <TrendingUp className="h-3.5 w-3.5 text-amber-500" />
                        <span className="text-xs text-muted-foreground">ربح محتمل:</span>
                        <span className="font-bold text-amber-600 text-sm">{potentialProfit.toLocaleString()} د.أ</span>
                      </div>
                    )}
                  </div>
                );
              })
            ) : (
              <div className="col-span-full text-center py-8 text-muted-foreground text-sm">
                لا توجد طلبات صيانة
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* تنبيهات */}
      {lowStockItems > 0 && (
        <Card className="border-red-200 bg-red-50 dark:bg-red-950/20">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-2 bg-red-500 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-red-600">تنبيه المخزون</p>
              <p className="text-sm text-red-500">يوجد {lowStockItems} منتج بكمية منخفضة</p>
            </div>
            <Button size="sm" onClick={() => onNavigate('inventory')}>
              عرض
            </Button>
          </CardContent>
        </Card>
      )}
      
      {/* تنبيه الديون */}
      {totalDebts > 0 && (
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-2 bg-orange-500 rounded-lg">
              <CreditCard className="h-5 w-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-orange-600">تنبيه الديون</p>
              <p className="text-sm text-orange-500">يوجد ديون مستحقة بقيمة {totalDebts.toLocaleString()} د.أ</p>
            </div>
            <Button size="sm" onClick={() => onNavigate('debts')}>
              عرض
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
