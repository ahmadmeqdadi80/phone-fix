'use client';

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Download,
  Upload,
  Database,
  AlertTriangle,
  CheckCircle,
  Loader2,
  FileJson,
  Users,
  Wrench,
  Package,
  FileText,
  Receipt,
} from 'lucide-react';
import { useAppStore } from '@/store';

interface BackupData {
  version: string;
  createdAt: string;
  data: {
    customers: any[];
    repairs: any[];
    inventory: any[];
    invoices: any[];
    expenses: any[];
  };
  stats: {
    customersCount: number;
    repairsCount: number;
    inventoryCount: number;
    invoicesCount: number;
    expensesCount: number;
  };
}

export function BackupRestore() {
  const { setCustomers, setRepairs, setInventory, setInvoices, setExpenses } = useAppStore();
  const [isCreating, setIsCreating] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [backupData, setBackupData] = useState<BackupData | null>(null);
  const [restoreResults, setRestoreResults] = useState<any>(null);
  const [showResultsDialog, setShowResultsDialog] = useState(false);
  const [overwrite, setOverwrite] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // إنشاء نسخة احتياطية
  const createBackup = async () => {
    setIsCreating(true);
    try {
      const response = await fetch('/api/backup');
      if (response.ok) {
        const data = await response.json();
        
        // تحويل إلى JSON وتحميل
        const jsonString = JSON.stringify(data, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const date = new Date().toISOString().split('T')[0];
        a.download = `نسخة_احتياطية_${date}.json`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
      }
    } catch (error) {
      console.error('Error creating backup:', error);
      alert('حدث خطأ أثناء إنشاء النسخة الاحتياطية');
    } finally {
      setIsCreating(false);
    }
  };

  // قراءة ملف النسخة الاحتياطية
  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const data = JSON.parse(text);
      
      // التحقق من صحة البيانات
      if (!data.version || !data.data) {
        alert('ملف النسخة الاحتياطية غير صالح');
        return;
      }

      setBackupData(data);
      setShowConfirmDialog(true);
    } catch (error) {
      console.error('Error reading backup file:', error);
      alert('حدث خطأ أثناء قراءة الملف');
    }

    // إعادة تعيين input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // استرجاع النسخة الاحتياطية
  const restoreBackup = async () => {
    if (!backupData) return;

    setIsRestoring(true);
    setShowConfirmDialog(false);

    try {
      const response = await fetch('/api/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          data: backupData.data,
          overwrite: overwrite,
        }),
      });

      if (response.ok) {
        const results = await response.json();
        setRestoreResults(results.results);
        setShowResultsDialog(true);

        // إعادة تحميل البيانات
        const [customersRes, repairsRes, inventoryRes, invoicesRes, expensesRes] = await Promise.all([
          fetch('/api/customers'),
          fetch('/api/repairs'),
          fetch('/api/inventory'),
          fetch('/api/invoices'),
          fetch('/api/expenses'),
        ]);

        if (customersRes.ok) setCustomers(await customersRes.json());
        if (repairsRes.ok) setRepairs(await repairsRes.json());
        if (inventoryRes.ok) setInventory(await inventoryRes.json());
        if (invoicesRes.ok) setInvoices(await invoicesRes.json());
        if (expensesRes.ok) setExpenses(await expensesRes.json());
      } else {
        alert('حدث خطأ أثناء استرجاع النسخة الاحتياطية');
      }
    } catch (error) {
      console.error('Error restoring backup:', error);
      alert('حدث خطأ أثناء استرجاع النسخة الاحتياطية');
    } finally {
      setIsRestoring(false);
      setBackupData(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* إنشاء نسخة احتياطية */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500 rounded-lg">
                <Download className="h-6 w-6 text-white" />
              </div>
              <div>
                <CardTitle>إنشاء نسخة احتياطية</CardTitle>
                <CardDescription>تصدير جميع البيانات إلى ملف JSON</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              قم بإنشاء نسخة احتياطية من جميع بياناتك (العملاء، الصيانة، المخزون، الفواتير، المصاريف)
              واحفظها على جهازك للاسترجاع لاحقاً.
            </p>
            <Button 
              onClick={createBackup} 
              disabled={isCreating}
              className="w-full gap-2"
            >
              {isCreating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  جاري الإنشاء...
                </>
              ) : (
                <>
                  <FileJson className="h-4 w-4" />
                  إنشاء نسخة احتياطية
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* استرجاع النسخة الاحتياطية */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500 rounded-lg">
                <Upload className="h-6 w-6 text-white" />
              </div>
              <div>
                <CardTitle>استرجاع نسخة احتياطية</CardTitle>
                <CardDescription>استيراد البيانات من ملف JSON</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              قم باسترجاع البيانات من نسخة احتياطية سابقة. يمكنك اختيار إضافة البيانات 
              أو استبدالها بالكامل.
            </p>
            <input
              type="file"
              accept=".json"
              ref={fileInputRef}
              onChange={handleFileSelect}
              className="hidden"
            />
            <Button 
              onClick={() => fileInputRef.current?.click()}
              disabled={isRestoring}
              variant="outline"
              className="w-full gap-2"
            >
              {isRestoring ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  جاري الاسترجاع...
                </>
              ) : (
                <>
                  <Database className="h-4 w-4" />
                  اختيار ملف النسخة الاحتياطية
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* حوار تأكيد الاسترجاع */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
              تأكيد استرجاع النسخة الاحتياطية
            </DialogTitle>
            <DialogDescription>
              تم العثور على النسخة الاحتياطية التالية:
            </DialogDescription>
          </DialogHeader>

          {backupData && (
            <div className="space-y-4 pt-4">
              <div className="p-4 bg-secondary rounded-lg">
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">تاريخ النسخة:</span>
                  <span className="font-medium">
                    {new Date(backupData.createdAt).toLocaleDateString('ar-SA')}
                  </span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">الإصدار:</span>
                  <span className="font-medium">{backupData.version}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>محتويات النسخة:</Label>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-2 p-2 bg-secondary rounded">
                    <Users className="h-4 w-4 text-blue-500" />
                    <span>{backupData.stats.customersCount} عميل</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-secondary rounded">
                    <Wrench className="h-4 w-4 text-purple-500" />
                    <span>{backupData.stats.repairsCount} طلب صيانة</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-secondary rounded">
                    <Package className="h-4 w-4 text-orange-500" />
                    <span>{backupData.stats.inventoryCount} عنصر مخزون</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-secondary rounded">
                    <FileText className="h-4 w-4 text-green-500" />
                    <span>{backupData.stats.invoicesCount} فاتورة</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-secondary rounded col-span-2">
                    <Receipt className="h-4 w-4 text-red-500" />
                    <span>{backupData.stats.expensesCount} مصروف</span>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                <Label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={overwrite}
                    onChange={(e) => setOverwrite(e.target.checked)}
                    className="rounded"
                  />
                  <span className="text-sm">استبدال البيانات الحالية (حذف كل البيانات القديمة)</span>
                </Label>
              </div>

              <div className="text-sm text-muted-foreground bg-red-50 dark:bg-red-950/20 p-3 rounded-lg">
                <AlertTriangle className="h-4 w-4 inline-block mr-1 text-red-500" />
                تحذير: استرجاع النسخة الاحتياطية قد يغير أو يحذف بياناتك الحالية.
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              إلغاء
            </Button>
            <Button onClick={restoreBackup} className="gap-2">
              <Upload className="h-4 w-4" />
              تأكيد الاسترجاع
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* حوار نتائج الاسترجاع */}
      <Dialog open={showResultsDialog} onOpenChange={setShowResultsDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle className="h-5 w-5" />
              تم استرجاع النسخة الاحتياطية
            </DialogTitle>
          </DialogHeader>

          {restoreResults && (
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                {[
                  { key: 'customers', label: 'العملاء', icon: Users },
                  { key: 'repairs', label: 'طلبات الصيانة', icon: Wrench },
                  { key: 'inventory', label: 'المخزون', icon: Package },
                  { key: 'invoices', label: 'الفواتير', icon: FileText },
                  { key: 'expenses', label: 'المصاريف', icon: Receipt },
                ].map(({ key, label, icon: Icon }) => (
                  <div key={key} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <div className="flex items-center gap-2">
                      <Icon className="h-4 w-4 text-muted-foreground" />
                      <span>{label}</span>
                    </div>
                    <div className="flex gap-3 text-sm">
                      <span className="text-green-600">
                        تم استيراد: {(restoreResults as any)[key]?.imported || 0}
                      </span>
                      {(restoreResults as any)[key]?.skipped > 0 && (
                        <span className="text-yellow-600">
                          تم تخطي: {(restoreResults as any)[key]?.skipped}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button onClick={() => setShowResultsDialog(false)}>
              إغلاق
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
