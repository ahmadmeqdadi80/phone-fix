'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Edit, Trash2, Eye, Wrench, TrendingUp, CreditCard, Banknote, XCircle } from 'lucide-react';
import { useAppStore, Repair } from '@/store';

const statusOptions = [
  { value: 'PENDING', label: 'قيد الانتظار', color: 'bg-yellow-500' },
  { value: 'DIAGNOSING', label: 'قيد التشخيص', color: 'bg-blue-500' },
  { value: 'WAITING_PARTS', label: 'في انتظار القطع', color: 'bg-orange-500' },
  { value: 'IN_PROGRESS', label: 'قيد الإصلاح', color: 'bg-purple-500' },
  { value: 'COMPLETED', label: 'تم الإصلاح', color: 'bg-green-500' },
  { value: 'DELIVERED', label: 'تم التسليم', color: 'bg-teal-500' },
  { value: 'CANCELLED', label: 'ملغي', color: 'bg-red-500' },
];

const deviceTypes = [
  'iPhone',
  'Samsung',
  'Huawei',
  'Xiaomi',
  'Oppo',
  'Vivo',
  'Realme',
  'Nokia',
  'LG',
  'HTC',
  'Sony',
  'Motorola',
  'أخرى',
];

export function RepairsPage() {
  const { repairs, customers, addRepair, updateRepair, deleteRepair } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [viewingRepair, setViewingRepair] = useState<Repair | null>(null);
  const [editingRepair, setEditingRepair] = useState<Repair | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  
  // حالة حوار الدفع عند التسليم
  const [isDeliveryDialogOpen, setIsDeliveryDialogOpen] = useState(false);
  const [deliveryRepair, setDeliveryRepair] = useState<Repair | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<'full' | 'partial' | 'none'>('full');
  const [deliveryPaidAmount, setDeliveryPaidAmount] = useState('');
  const [deliveryDebt, setDeliveryDebt] = useState('');

  const [formData, setFormData] = useState({
    customerId: '',
    deviceType: '',
    deviceModel: '',
    entryDate: new Date().toISOString().split('T')[0],
    problem: '',
    diagnosis: '',
    solution: '',
    status: 'PENDING',
    maintenanceCost: '',
    finalCost: '',
    deposit: '',
    estimatedDate: '',
    notes: '',
  });

  // تحميل البيانات
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [repairsRes, customersRes] = await Promise.all([
          fetch('/api/repairs'),
          fetch('/api/customers'),
        ]);
        if (repairsRes.ok) {
          const repairsData = await repairsRes.json();
          useAppStore.getState().setRepairs(repairsData);
        }
        if (customersRes.ok) {
          const customersData = await customersRes.json();
          useAppStore.getState().setCustomers(customersData);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  const filteredRepairs = repairs.filter(r => {
    const matchesSearch =
      r.deviceModel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.problem.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customers.find(c => c.id === r.customerId)?.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // حساب الربح من الصيانة (يظهر فقط إذا كانت الحالة DELIVERED)
  const calculateProfit = (repair: Repair) => {
    if (repair.status === 'DELIVERED' && repair.finalCost && repair.maintenanceCost) {
      return repair.finalCost - repair.maintenanceCost;
    }
    return null;
  };

  // حساب الربح المحتمل (للطلبات غير المسلمة)
  const calculatePotentialProfit = (repair: Repair) => {
    if (repair.finalCost && repair.maintenanceCost) {
      return repair.finalCost - repair.maintenanceCost;
    }
    return null;
  };

  const handleSubmit = async () => {
    if (!formData.customerId || !formData.deviceType || !formData.deviceModel || !formData.problem) return;

    const data = {
      ...formData,
      entryDate: formData.entryDate ? new Date(formData.entryDate).toISOString() : new Date().toISOString(),
      maintenanceCost: formData.maintenanceCost ? parseFloat(formData.maintenanceCost) : null,
      finalCost: formData.finalCost ? parseFloat(formData.finalCost) : null,
      deposit: formData.deposit ? parseFloat(formData.deposit) : 0,
      estimatedDate: formData.estimatedDate || null,
    };

    if (editingRepair) {
      // إذا كان التعديل يغير الحالة إلى DELIVERED، نفتح حوار الدفع
      if (formData.status === 'DELIVERED' && editingRepair.status !== 'DELIVERED') {
        setDeliveryRepair(editingRepair);
        const finalCost = formData.finalCost ? parseFloat(formData.finalCost) : 0;
        const deposit = formData.deposit ? parseFloat(formData.deposit) : 0;
        setDeliveryPaidAmount((finalCost - deposit).toString());
        setDeliveryDebt('0');
        setPaymentStatus('full');
        setIsDeliveryDialogOpen(true);
        setIsDialogOpen(false);
        return;
      }
      
      const response = await fetch('/api/repairs', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editingRepair.id, ...data }),
      });
      if (response.ok) {
        const updated = await response.json();
        updateRepair(editingRepair.id, updated);
      }
    } else {
      const response = await fetch('/api/repairs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (response.ok) {
        const newRepair = await response.json();
        addRepair(newRepair);
      }
    }

    setIsDialogOpen(false);
    resetForm();
  };

  // معالجة تأكيد التسليم مع الدفع
  const handleDeliveryConfirm = async () => {
    if (!deliveryRepair) return;
    
    const finalCost = deliveryRepair.finalCost || parseFloat(formData.finalCost) || 0;
    const paidAmount = parseFloat(deliveryPaidAmount) || 0;
    const debt = parseFloat(deliveryDebt) || 0;
    
    const updateData = {
      id: deliveryRepair.id,
      status: 'DELIVERED',
      finalCost: finalCost,
      paidAmount: paidAmount,
      debt: debt,
      deliveredAt: new Date().toISOString(),
    };
    
    const response = await fetch('/api/repairs', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updateData),
    });
    
    if (response.ok) {
      const updated = await response.json();
      updateRepair(deliveryRepair.id, updated);
    }
    
    setIsDeliveryDialogOpen(false);
    setDeliveryRepair(null);
    resetForm();
  };

  const handleEdit = (repair: Repair) => {
    setEditingRepair(repair);
    setFormData({
      customerId: repair.customerId,
      deviceType: repair.deviceType,
      deviceModel: repair.deviceModel,
      entryDate: repair.entryDate ? repair.entryDate.split('T')[0] : new Date().toISOString().split('T')[0],
      problem: repair.problem,
      diagnosis: repair.diagnosis || '',
      solution: repair.solution || '',
      status: repair.status,
      maintenanceCost: repair.maintenanceCost?.toString() || '',
      finalCost: repair.finalCost?.toString() || '',
      deposit: repair.deposit.toString(),
      estimatedDate: repair.estimatedDate ? repair.estimatedDate.split('T')[0] : '',
      notes: repair.notes || '',
    });
    setIsDialogOpen(true);
  };

  const handleView = (repair: Repair) => {
    setViewingRepair(repair);
    setIsViewOpen(true);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const response = await fetch(`/api/repairs?id=${deleteId}`, { method: 'DELETE' });
    if (response.ok) {
      deleteRepair(deleteId);
    }
    setDeleteId(null);
  };

  const resetForm = () => {
    setFormData({
      customerId: '',
      deviceType: '',
      deviceModel: '',
      entryDate: new Date().toISOString().split('T')[0],
      problem: '',
      diagnosis: '',
      solution: '',
      status: 'PENDING',
      maintenanceCost: '',
      finalCost: '',
      deposit: '',
      estimatedDate: '',
      notes: '',
    });
    setEditingRepair(null);
  };

  const getStatusBadge = (status: string) => {
    const statusInfo = statusOptions.find(s => s.value === status);
    return (
      <Badge className={`${statusInfo?.color} text-white`}>
        {statusInfo?.label}
      </Badge>
    );
  };

  const getCustomerName = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.name || 'غير معروف';
  };

  // تغيير حالة الطلب مباشرة من الجدول
  const handleStatusChange = async (repair: Repair, newStatus: string) => {
    if (newStatus === 'DELIVERED' && repair.status !== 'DELIVERED') {
      // فتح حوار الدفع
      setDeliveryRepair(repair);
      setFormData({
        customerId: repair.customerId,
        deviceType: repair.deviceType,
        deviceModel: repair.deviceModel,
        entryDate: repair.entryDate ? repair.entryDate.split('T')[0] : new Date().toISOString().split('T')[0],
        problem: repair.problem,
        diagnosis: repair.diagnosis || '',
        solution: repair.solution || '',
        status: newStatus,
        maintenanceCost: repair.maintenanceCost?.toString() || '',
        finalCost: repair.finalCost?.toString() || '',
        deposit: repair.deposit.toString(),
        estimatedDate: repair.estimatedDate ? repair.estimatedDate.split('T')[0] : '',
        notes: repair.notes || '',
      });
      const finalCost = repair.finalCost || 0;
      const remainingAmount = finalCost - repair.deposit;
      setDeliveryPaidAmount(remainingAmount.toString());
      setDeliveryDebt('0');
      setPaymentStatus('full');
      setIsDeliveryDialogOpen(true);
      return;
    }
    
    // تحديث الحالة مباشرة
    const updateData: Record<string, unknown> = { status: newStatus };
    if (newStatus === 'COMPLETED') {
      updateData.completedAt = new Date().toISOString();
    }
    
    const response = await fetch('/api/repairs', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: repair.id, ...updateData }),
    });
    
    if (response.ok) {
      const updated = await response.json();
      updateRepair(repair.id, updated);
    }
  };

  return (
    <div className="space-y-6">
      {/* العنوان */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">طلبات الصيانة</h1>
          <p className="text-muted-foreground">إدارة طلبات صيانة الأجهزة</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              طلب صيانة جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingRepair ? 'تعديل طلب صيانة' : 'طلب صيانة جديد'}</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
              <div className="space-y-2">
                <Label>العميل *</Label>
                <Select value={formData.customerId} onValueChange={(v) => setFormData({ ...formData, customerId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر العميل" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>نوع الجهاز *</Label>
                <Select value={formData.deviceType} onValueChange={(v) => setFormData({ ...formData, deviceType: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر النوع" />
                  </SelectTrigger>
                  <SelectContent>
                    {deviceTypes.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>موديل الجهاز *</Label>
                <Input
                  value={formData.deviceModel}
                  onChange={(e) => setFormData({ ...formData, deviceModel: e.target.value })}
                  placeholder="مثال: iPhone 14 Pro"
                />
              </div>
              <div className="space-y-2">
                <Label>تاريخ الإدخال</Label>
                <Input
                  type="date"
                  value={formData.entryDate}
                  onChange={(e) => setFormData({ ...formData, entryDate: e.target.value })}
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>المشكلة المبلغ عنها *</Label>
                <Textarea
                  value={formData.problem}
                  onChange={(e) => setFormData({ ...formData, problem: e.target.value })}
                  placeholder="وصف المشكلة..."
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>التشخيص</Label>
                <Textarea
                  value={formData.diagnosis}
                  onChange={(e) => setFormData({ ...formData, diagnosis: e.target.value })}
                  placeholder="التشخيص الفني..."
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>الحل / الإصلاح</Label>
                <Textarea
                  value={formData.solution}
                  onChange={(e) => setFormData({ ...formData, solution: e.target.value })}
                  placeholder="وصف الإصلاح..."
                />
              </div>
              <div className="space-y-2">
                <Label>الحالة</Label>
                <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((s) => (
                      <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>العربون</Label>
                <Input
                  type="number"
                  value={formData.deposit}
                  onChange={(e) => setFormData({ ...formData, deposit: e.target.value })}
                  placeholder="0.00"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  تكلفة الصيانة
                  <span className="text-xs text-muted-foreground">(قطع الغيار + مواد)</span>
                </Label>
                <Input
                  type="number"
                  value={formData.maintenanceCost}
                  onChange={(e) => setFormData({ ...formData, maintenanceCost: e.target.value })}
                  placeholder="0.00"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label>السعر النهائي للعميل</Label>
                <Input
                  type="number"
                  value={formData.finalCost}
                  onChange={(e) => setFormData({ ...formData, finalCost: e.target.value })}
                  placeholder="0.00"
                  dir="ltr"
                />
              </div>
              
              {/* عرض الربح المتوقع */}
              {formData.maintenanceCost && formData.finalCost && (
                <div className="space-y-2 md:col-span-2">
                  <div className="p-3 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                    <div className="flex items-center gap-2 text-green-600">
                      <TrendingUp className="h-4 w-4" />
                      <span className="font-medium">
                        الربح المتوقع: {((parseFloat(formData.finalCost) || 0) - (parseFloat(formData.maintenanceCost) || 0)).toLocaleString()} د.أ
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      سيتم احتساب الربح عند تغيير الحالة إلى "تم التسليم"
                    </p>
                  </div>
                </div>
              )}
              
              <div className="space-y-2">
                <Label>التاريخ المتوقع للتسليم</Label>
                <Input
                  type="date"
                  value={formData.estimatedDate}
                  onChange={(e) => setFormData({ ...formData, estimatedDate: e.target.value })}
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>ملاحظات</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="ملاحظات إضافية..."
                />
              </div>
              <div className="flex gap-2 justify-end md:col-span-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  إلغاء
                </Button>
                <Button onClick={handleSubmit}>
                  {editingRepair ? 'تحديث' : 'إضافة'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* البحث والفلترة */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث بالموديل، المشكلة، أو العميل..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="جميع الحالات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الحالات</SelectItem>
                {statusOptions.map((s) => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* جدول الطلبات */}
      <Card>
        <CardHeader>
          <CardTitle>طلبات الصيانة ({filteredRepairs.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredRepairs.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>العميل</TableHead>
                    <TableHead>الجهاز</TableHead>
                    <TableHead>المشكلة</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>السعر النهائي</TableHead>
                    <TableHead>الربح</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead className="text-left">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRepairs.map((repair) => {
                    const profit = calculateProfit(repair);
                    const potentialProfit = calculatePotentialProfit(repair);
                    return (
                      <TableRow key={repair.id}>
                        <TableCell className="font-medium">{getCustomerName(repair.customerId)}</TableCell>
                        <TableCell>
                          <div>
                            <p>{repair.deviceType}</p>
                            <p className="text-xs text-muted-foreground">{repair.deviceModel}</p>
                          </div>
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate">{repair.problem}</TableCell>
                        <TableCell>
                          <Select 
                            value={repair.status} 
                            onValueChange={(v) => handleStatusChange(repair, v)}
                          >
                            <SelectTrigger className="w-32 h-8">
                              <Badge className={`${statusOptions.find(s => s.value === repair.status)?.color} text-white`}>
                                {statusOptions.find(s => s.value === repair.status)?.label}
                              </Badge>
                            </SelectTrigger>
                            <SelectContent>
                              {statusOptions.map((s) => (
                                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          {repair.finalCost ? (
                            <span>{repair.finalCost.toLocaleString()} د.أ</span>
                          ) : '-'}
                        </TableCell>
                        <TableCell>
                          {profit !== null ? (
                            <span className="text-green-600 font-medium">
                              {profit.toLocaleString()} د.أ
                            </span>
                          ) : potentialProfit !== null ? (
                            <span className="text-muted-foreground text-sm">
                              ({potentialProfit.toLocaleString()} د.أ محتمل)
                            </span>
                          ) : '-'}
                        </TableCell>
                        <TableCell>
                          {new Date(repair.entryDate || repair.createdAt).toLocaleDateString('ar-SA')}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" onClick={() => handleView(repair)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(repair)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => setDeleteId(repair.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <Wrench className="h-12 w-12 mx-auto mb-4 opacity-50" />
              {searchTerm || statusFilter !== 'all' ? 'لا توجد نتائج للبحث' : 'لا توجد طلبات صيانة. أضف طلبك الأول!'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* حوار عرض التفاصيل */}
      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>تفاصيل طلب الصيانة</DialogTitle>
          </DialogHeader>
          {viewingRepair && (
            <div className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">العميل</Label>
                  <p className="font-medium">{getCustomerName(viewingRepair.customerId)}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">الجهاز</Label>
                  <p className="font-medium">{viewingRepair.deviceType} - {viewingRepair.deviceModel}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">تاريخ الإدخال</Label>
                  <p className="font-medium">{new Date(viewingRepair.entryDate || viewingRepair.createdAt).toLocaleDateString('ar-SA')}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">الحالة</Label>
                  <div>{getStatusBadge(viewingRepair.status)}</div>
                </div>
              </div>
              <div>
                <Label className="text-muted-foreground">المشكلة</Label>
                <p className="bg-secondary p-3 rounded-lg mt-1">{viewingRepair.problem}</p>
              </div>
              {viewingRepair.diagnosis && (
                <div>
                  <Label className="text-muted-foreground">التشخيص</Label>
                  <p className="bg-secondary p-3 rounded-lg mt-1">{viewingRepair.diagnosis}</p>
                </div>
              )}
              {viewingRepair.solution && (
                <div>
                  <Label className="text-muted-foreground">الحل</Label>
                  <p className="bg-secondary p-3 rounded-lg mt-1">{viewingRepair.solution}</p>
                </div>
              )}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-muted-foreground">العربون</Label>
                  <p className="font-medium">{viewingRepair.deposit.toLocaleString()} د.أ</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">تكلفة الصيانة</Label>
                  <p className="font-medium text-red-600">{viewingRepair.maintenanceCost?.toLocaleString() || '-'} د.أ</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">السعر النهائي</Label>
                  <p className="font-medium text-blue-600">{viewingRepair.finalCost?.toLocaleString() || '-'} د.أ</p>
                </div>
              </div>
              
              {/* عرض معلومات الدفع للتسليمات */}
              {viewingRepair.status === 'DELIVERED' && (
                <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-center gap-2 text-blue-600 mb-3">
                    <CreditCard className="h-5 w-5" />
                    <span className="font-bold">معلومات الدفع</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">المبلغ المدفوع:</span>
                      <p className="font-bold text-green-600">{(viewingRepair.paidAmount || 0).toLocaleString()} د.أ</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">المتبقي (دين):</span>
                      <p className="font-bold text-red-600">{(viewingRepair.debt || 0).toLocaleString()} د.أ</p>
                    </div>
                  </div>
                </div>
              )}
              
              {/* عرض الربح للتسليمات فقط */}
              {viewingRepair.status === 'DELIVERED' && calculateProfit(viewingRepair) !== null && (
                <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-green-600">
                      <TrendingUp className="h-5 w-5" />
                      <span className="font-bold text-lg">الربح من الصيانة</span>
                    </div>
                    <span className="font-bold text-xl text-green-600">
                      {calculateProfit(viewingRepair)?.toLocaleString()} د.أ
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    السعر النهائي ({viewingRepair.finalCost?.toLocaleString()} د.أ) - تكلفة الصيانة ({viewingRepair.maintenanceCost?.toLocaleString()} د.أ)
                  </p>
                </div>
              )}
              
              {/* عرض الربح المحتمل للطلبات غير المسلمة */}
              {viewingRepair.status !== 'DELIVERED' && calculatePotentialProfit(viewingRepair) !== null && (
                <div className="p-4 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-amber-600">
                      <TrendingUp className="h-5 w-5" />
                      <span className="font-bold text-lg">الربح المحتمل</span>
                    </div>
                    <span className="font-bold text-xl text-amber-600">
                      {calculatePotentialProfit(viewingRepair)?.toLocaleString()} د.أ
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    سيتم احتساب الربح عند تغيير الحالة إلى "تم التسليم"
                  </p>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                <div>تاريخ الإدخال: {new Date(viewingRepair.entryDate || viewingRepair.createdAt).toLocaleDateString('ar-SA')}</div>
                {viewingRepair.estimatedDate && (
                  <div>التاريخ المتوقع: {new Date(viewingRepair.estimatedDate).toLocaleDateString('ar-SA')}</div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* حوار الدفع عند التسليم */}
      <Dialog open={isDeliveryDialogOpen} onOpenChange={setIsDeliveryDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              تأكيد التسليم والدفع
            </DialogTitle>
            <DialogDescription>
              حدد حالة الدفع للعميل قبل تأكيد التسليم
            </DialogDescription>
          </DialogHeader>
          
          {deliveryRepair && (
            <div className="space-y-4 pt-4">
              {/* ملخص الطلب */}
              <div className="p-3 bg-secondary rounded-lg">
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">العميل:</span>
                  <span className="font-medium">{getCustomerName(deliveryRepair.customerId)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">الجهاز:</span>
                  <span className="font-medium">{deliveryRepair.deviceModel}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">السعر النهائي:</span>
                  <span className="font-bold text-blue-600">{(deliveryRepair.finalCost || 0).toLocaleString()} د.أ</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">العربون:</span>
                  <span className="font-medium text-green-600">{deliveryRepair.deposit.toLocaleString()} د.أ</span>
                </div>
              </div>
              
              {/* المتبقي للدفع */}
              <div className="p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">المتبقي للدفع:</span>
                  <span className="font-bold text-amber-600">
                    {((deliveryRepair.finalCost || 0) - deliveryRepair.deposit).toLocaleString()} د.أ
                  </span>
                </div>
              </div>
              
              {/* خيارات الدفع */}
              <div className="space-y-3">
                <Label>حالة الدفع</Label>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    type="button"
                    variant={paymentStatus === 'full' ? 'default' : 'outline'}
                    className={`h-auto py-3 flex-col ${paymentStatus === 'full' ? 'bg-green-500 hover:bg-green-600' : ''}`}
                    onClick={() => {
                      setPaymentStatus('full');
                      const remaining = (deliveryRepair.finalCost || 0) - deliveryRepair.deposit;
                      setDeliveryPaidAmount(remaining.toString());
                      setDeliveryDebt('0');
                    }}
                  >
                    <Banknote className="h-5 w-5 mb-1" />
                    <span className="text-sm font-medium">دفع كامل</span>
                  </Button>
                  <Button
                    type="button"
                    variant={paymentStatus === 'partial' ? 'default' : 'outline'}
                    className={`h-auto py-3 flex-col ${paymentStatus === 'partial' ? 'bg-orange-500 hover:bg-orange-600' : ''}`}
                    onClick={() => {
                      setPaymentStatus('partial');
                      setDeliveryPaidAmount('');
                      setDeliveryDebt('');
                    }}
                  >
                    <CreditCard className="h-5 w-5 mb-1" />
                    <span className="text-sm font-medium">دفع جزئي</span>
                  </Button>
                  <Button
                    type="button"
                    variant={paymentStatus === 'none' ? 'default' : 'outline'}
                    className={`h-auto py-3 flex-col ${paymentStatus === 'none' ? 'bg-red-500 hover:bg-red-600' : ''}`}
                    onClick={() => {
                      setPaymentStatus('none');
                      const remaining = (deliveryRepair.finalCost || 0) - deliveryRepair.deposit;
                      setDeliveryPaidAmount('0');
                      setDeliveryDebt(remaining.toString());
                    }}
                  >
                    <XCircle className="h-5 w-5 mb-1" />
                    <span className="text-sm font-medium">لم يدفع</span>
                  </Button>
                </div>
              </div>
              
              {/* حقول الدفع الجزئي */}
              {paymentStatus === 'partial' && (
                <div className="space-y-3 p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800">
                  <div className="space-y-2">
                    <Label>المبلغ المدفوع الآن</Label>
                    <Input
                      type="number"
                      value={deliveryPaidAmount}
                      onChange={(e) => {
                        const paid = parseFloat(e.target.value) || 0;
                        const remaining = (deliveryRepair.finalCost || 0) - deliveryRepair.deposit - paid;
                        setDeliveryPaidAmount(e.target.value);
                        setDeliveryDebt(Math.max(0, remaining).toString());
                      }}
                      placeholder="0.00"
                      dir="ltr"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>المبلغ المتبقي (الدين)</Label>
                    <Input
                      type="number"
                      value={deliveryDebt}
                      onChange={(e) => {
                        const debt = parseFloat(e.target.value) || 0;
                        const paid = (deliveryRepair.finalCost || 0) - deliveryRepair.deposit - debt;
                        setDeliveryDebt(e.target.value);
                        setDeliveryPaidAmount(Math.max(0, paid).toString());
                      }}
                      placeholder="0.00"
                      dir="ltr"
                    />
                  </div>
                </div>
              )}
              
              {/* عرض ملخص الدفع */}
              {paymentStatus === 'full' && (
                <div className="p-3 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">المبلغ المدفوع:</span>
                    <span className="font-bold text-green-600">
                      {((deliveryRepair.finalCost || 0) - deliveryRepair.deposit).toLocaleString()} د.أ
                    </span>
                  </div>
                </div>
              )}
              
              {/* عرض ملخص عدم الدفع */}
              {paymentStatus === 'none' && (
                <div className="p-3 bg-red-50 dark:bg-red-950/20 rounded-lg border border-red-200 dark:border-red-800">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">الدين المستحق:</span>
                    <span className="font-bold text-red-600">
                      {((deliveryRepair.finalCost || 0) - deliveryRepair.deposit).toLocaleString()} د.أ
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    سيتم إضافة هذا المبلغ إلى ديون العميل
                  </p>
                </div>
              )}
              
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setIsDeliveryDialogOpen(false)}>
                  إلغاء
                </Button>
                <Button onClick={handleDeliveryConfirm} className="bg-green-500 hover:bg-green-600">
                  تأكيد التسليم
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* حوار تأكيد الحذف */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف هذا الطلب؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-500 hover:bg-red-600">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
