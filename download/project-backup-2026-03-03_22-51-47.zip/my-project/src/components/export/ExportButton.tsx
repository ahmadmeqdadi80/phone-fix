'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Download, FileSpreadsheet, FileText, Loader2 } from 'lucide-react';
import { useAppStore } from '@/store';

interface ExportButtonProps {
  type: 'all' | 'customers' | 'repairs' | 'inventory' | 'invoices' | 'expenses';
  label: string;
}

// تسميات الحالات
const statusLabels: Record<string, string> = {
  'PENDING': 'قيد الانتظار',
  'DIAGNOSING': 'قيد التشخيص',
  'WAITING_PARTS': 'في انتظار القطع',
  'IN_PROGRESS': 'قيد الإصلاح',
  'COMPLETED': 'تم الإصلاح',
  'DELIVERED': 'تم التسليم',
  'CANCELLED': 'ملغي',
  'PAID': 'مدفوعة',
  'PARTIAL': 'مدفوعة جزئياً',
};

const formatDate = (date: string | Date): string => {
  return new Date(date).toLocaleDateString('ar-SA');
};

export function ExportButton({ type, label }: ExportButtonProps) {
  const { customers, repairs, inventory, invoices, expenses } = useAppStore();
  const [isExporting, setIsExporting] = useState(false);
  const [format, setFormat] = useState<'excel' | 'pdf'>('excel');

  const exportToExcel = async () => {
    setIsExporting(true);
    try {
      const response = await fetch(`/api/export?type=${type}`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = response.headers.get('content-disposition')?.split('filename=')[1]?.replace(/"/g, '') || 'export.xlsx';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
      }
    } catch (error) {
      console.error('Error exporting:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const generatePDFContent = (): string => {
    const date = new Date().toLocaleDateString('ar-SA');
    let html = `
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <title>تقرير</title>
        <style>
          * { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; }
          body { direction: rtl; padding: 20px; }
          h1 { text-align: center; color: #2980b9; margin-bottom: 5px; }
          .date { text-align: center; color: #666; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
          th { background-color: #2980b9; color: white; padding: 10px; text-align: center; }
          td { border: 1px solid #ddd; padding: 8px; text-align: center; }
          tr:nth-child(even) { background-color: #f5f5f5; }
          .page-break { page-break-after: always; }
          @media print {
            .page-break { page-break-after: always; }
          }
        </style>
      </head>
      <body>
    `;

    // تقرير العملاء
    if (type === 'all' || type === 'customers') {
      html += `
        <h1>تقرير العملاء</h1>
        <p class="date">التاريخ: ${date}</p>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>الاسم</th>
              <th>الهاتف</th>
              <th>البريد الإلكتروني</th>
              <th>العنوان</th>
              <th>ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            ${customers.map((c, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${c.name}</td>
                <td>${c.phone}</td>
                <td>${c.email || '-'}</td>
                <td>${c.address || '-'}</td>
                <td>${c.notes || '-'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        ${type === 'all' ? '<div class="page-break"></div>' : ''}
      `;
    }

    // تقرير الصيانة
    if (type === 'all' || type === 'repairs') {
      html += `
        <h1>تقرير طلبات الصيانة</h1>
        <p class="date">التاريخ: ${date}</p>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>العميل</th>
              <th>الجهاز</th>
              <th>المشكلة</th>
              <th>الحالة</th>
              <th>السعر</th>
              <th>المدفوع</th>
              <th>الدين</th>
            </tr>
          </thead>
          <tbody>
            ${repairs.map((r, i) => {
              const customer = customers.find(c => c.id === r.customerId);
              return `
                <tr>
                  <td>${i + 1}</td>
                  <td>${customer?.name || '-'}</td>
                  <td>${r.deviceType} - ${r.deviceModel}</td>
                  <td>${r.problem.substring(0, 30)}${r.problem.length > 30 ? '...' : ''}</td>
                  <td>${statusLabels[r.status] || r.status}</td>
                  <td>${r.finalCost ? r.finalCost + ' د.أ' : '-'}</td>
                  <td>${r.paidAmount} د.أ</td>
                  <td>${r.debt} د.أ</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
        ${type === 'all' ? '<div class="page-break"></div>' : ''}
      `;
    }

    // تقرير المخزون
    if (type === 'all' || type === 'inventory') {
      html += `
        <h1>تقرير المخزون</h1>
        <p class="date">التاريخ: ${date}</p>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>اسم القطعة</th>
              <th>الفئة</th>
              <th>الكمية</th>
              <th>سعر الشراء</th>
              <th>سعر البيع</th>
            </tr>
          </thead>
          <tbody>
            ${inventory.map((item, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${item.name}</td>
                <td>${item.category}</td>
                <td>${item.quantity}</td>
                <td>${item.costPrice} د.أ</td>
                <td>${item.sellingPrice} د.أ</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        ${type === 'all' ? '<div class="page-break"></div>' : ''}
      `;
    }

    // تقرير الفواتير
    if (type === 'all' || type === 'invoices') {
      html += `
        <h1>تقرير الفواتير</h1>
        <p class="date">التاريخ: ${date}</p>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>رقم الفاتورة</th>
              <th>العميل</th>
              <th>الإجمالي</th>
              <th>المدفوع</th>
              <th>الحالة</th>
            </tr>
          </thead>
          <tbody>
            ${invoices.map((inv, i) => {
              const customer = customers.find(c => c.id === inv.customerId);
              return `
                <tr>
                  <td>${i + 1}</td>
                  <td>${inv.invoiceNumber}</td>
                  <td>${customer?.name || '-'}</td>
                  <td>${inv.total} د.أ</td>
                  <td>${inv.paid} د.أ</td>
                  <td>${statusLabels[inv.status] || inv.status}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
        ${type === 'all' ? '<div class="page-break"></div>' : ''}
      `;
    }

    // تقرير المصاريف
    if (type === 'all' || type === 'expenses') {
      html += `
        <h1>تقرير المصاريف</h1>
        <p class="date">التاريخ: ${date}</p>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>الفئة</th>
              <th>الوصف</th>
              <th>المبلغ</th>
              <th>التاريخ</th>
            </tr>
          </thead>
          <tbody>
            ${expenses.map((e, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${e.category}</td>
                <td>${e.description}</td>
                <td>${e.amount} د.أ</td>
                <td>${formatDate(e.date)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    html += `
      </body>
      </html>
    `;

    return html;
  };

  const exportToPDF = () => {
    setIsExporting(true);
    try {
      const htmlContent = generatePDFContent();
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(htmlContent);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          setIsExporting(false);
        }, 500);
      } else {
        setIsExporting(false);
        alert('يرجى السماح بالنوافذ المنبثقة للتصدير');
      }
    } catch (error) {
      console.error('Error exporting PDF:', error);
      setIsExporting(false);
    }
  };

  const handleExport = () => {
    if (format === 'excel') {
      exportToExcel();
    } else {
      exportToPDF();
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Select value={format} onValueChange={(v) => setFormat(v as 'excel' | 'pdf')}>
        <SelectTrigger className="w-28">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="excel">Excel</SelectItem>
          <SelectItem value="pdf">PDF</SelectItem>
        </SelectContent>
      </Select>
      <Button onClick={handleExport} disabled={isExporting} className="gap-2">
        {isExporting ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : format === 'excel' ? (
          <FileSpreadsheet className="h-4 w-4" />
        ) : (
          <FileText className="h-4 w-4" />
        )}
        {label}
      </Button>
    </div>
  );
}

export function ExportDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          تصدير البيانات
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>تصدير البيانات</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <p className="text-sm text-muted-foreground">
            اختر نوع البيانات والصيغة المطلوبة للتصدير
          </p>
          <div className="grid gap-3">
            <ExportButton type="all" label="تصدير الكل" />
            <ExportButton type="customers" label="العملاء" />
            <ExportButton type="repairs" label="طلبات الصيانة" />
            <ExportButton type="inventory" label="المخزون" />
            <ExportButton type="invoices" label="الفواتير" />
            <ExportButton type="expenses" label="المصاريف" />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
